#!/bin/sh
cp patch_ok /home/ctf/challenge/cgi